package com.example.codebubble

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "Определитель кода"
            textSize = 28f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Включи пузырёк и пользуйся им поверх любых приложений.\n\n" +
                "1. Скопируй код в любом приложении.\n" +
                "2. Нажми на пузырёк </>.\n" +
                "3. Появится ответ, что это за код.\n\n" +
                "Пузырёк можно перетаскивать. Чтобы убрать ответ, нажми на него."
            textSize = 16f
        }, lp(top = 16))

        root.addView(Button(this).apply {
            text = "Включить пузырёк"
            setOnClickListener { start() }
        }, lp(top = 24))

        root.addView(Button(this).apply {
            text = "Выключить пузырёк"
            setOnClickListener {
                stopService(Intent(this@MainActivity, BubbleService::class.java))
                toast("Пузырёк выключен")
            }
        }, lp(top = 8))

        status = TextView(this).apply { textSize = 14f; gravity = Gravity.START }
        root.addView(status, lp(top = 16))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this)) {
            "Доступ «поверх других приложений» выдан."
        } else {
            "Нужен доступ «поверх других приложений». Он запросится при включении."
        }
    }

    private fun lp(top: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Разреши показ поверх других приложений и вернись назад")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        launch()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        // Пузырёк работает и без уведомления, поэтому запускаем в любом случае
        launch()
    }

    private fun launch() {
        startForegroundService(Intent(this, BubbleService::class.java))
        toast("Пузырёк включён")
        finish()
    }
}
