package com.example.codebubble

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.WebView
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var lastText: String = ""
    private var runner: WebView? = null
    private val main = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        addBubble()
        Bridge.onText = { onClip(it) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        Bridge.onText = null
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Пузырёк", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, BubbleService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Определитель кода работает")
            .setContentText("Скопируй код и нажми на пузырёк")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Выключить", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )

    private fun addBubble() {
        val size = dp(56)
        val tv = TextView(this).apply {
            text = BUBBLE_TEXT
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.MONOSPACE
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF0F766E.toInt())
                setStroke(dp(2), 0x66FFFFFF)
            }
        }
        val lp = overlayParams(size, size).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(220)
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > slop || abs(dy) > slop) {
                        if (!moved) hidePanel()
                        moved = true
                    }
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        wm.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onBubbleTap()
                    true
                }
                else -> false
            }
        }

        wm.addView(tv, lp)
        bubble = tv
        bubbleLp = lp
    }

    private fun onBubbleTap() {
        if (panel != null) {
            hidePanel()
            return
        }
        bubble?.text = "…"
        startActivity(
            Intent(this, ClipActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            )
        )
    }

    private fun onClip(text: String?) {
        bubble?.text = BUBBLE_TEXT
        lastText = text ?: ""
        val v = if (text.isNullOrBlank()) {
            Verdict("Буфер пуст", "", "Скопируй код и нажми на пузырёк ещё раз.", "", true, emptyList(), false)
        } else {
            Detector.detect(text)
        }
        showPanel(v)
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun LinearLayout.addRow(v: View, topDp: Int = 0) {
        addView(v, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(topDp) })
    }

    private fun showPanel(v: Verdict) {
        hidePanel()
        val dm = resources.displayMetrics
        val width = minOf(dm.widthPixels - dp(32), dp(340))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(14))
            background = GradientDrawable().apply {
                setColor(0xFF15212A.toInt())
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), 0xFF263642.toInt())
            }
        }

        col.addRow(label(v.name, 24f, 0xFFE4EDF2.toInt(), bold = true))
        val meta = listOf(v.ext, v.label).filter { it.isNotEmpty() }.joinToString("  ·  ")
        if (meta.isNotEmpty()) {
            col.addRow(label(meta, 13f, if (v.low) 0xFFF2B25C.toInt() else 0xFF4FD1C0.toInt()), 4)
        }
        col.addRow(label(v.desc, 15f, 0xFFB8C7D1.toInt()), 10)
        if (v.secret) {
            col.addRow(label("Это секрет. Не показывай его другим и не публикуй.", 14f, 0xFFF2B25C.toInt()), 10)
        }
        if (v.name == "JavaScript" || v.name == "HTML") {
            val btn = label("▶ Запустить", 16f, 0xFF06211D.toInt(), bold = true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = GradientDrawable().apply {
                    setColor(0xFF4FD1C0.toInt())
                    cornerRadius = dp(10).toFloat()
                }
            }
            val out = label("", 13f, 0xFFE4EDF2.toInt()).apply {
                typeface = Typeface.MONOSPACE
                maxLines = 12
                visibility = View.GONE
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = GradientDrawable().apply {
                    setColor(0xFF0E161D.toInt())
                    cornerRadius = dp(8).toFloat()
                }
            }
            btn.setOnClickListener {
                if (v.name == "HTML") openHtml(lastText) else runJs(lastText, out)
            }
            col.addRow(btn, 12)
            col.addRow(out, 8)
        }
        if (v.others.isNotEmpty()) {
            col.addRow(label("Ещё похоже: " + v.others.joinToString(", "), 13f, 0xFF8EA1AE.toInt()), 10)
        }
        col.addRow(label("Нажми, чтобы закрыть", 12f, 0xFF8EA1AE.toInt()), 12)
        col.setOnClickListener { hidePanel() }

        val lp = overlayParams(width, ViewGroup.LayoutParams.WRAP_CONTENT)
        val by = bubbleLp?.y ?: 0
        if (by > dm.heightPixels / 2) {
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            lp.y = dm.heightPixels - by + dp(8)
        } else {
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            lp.y = by + dp(56 + 8)
        }
        wm.addView(col, lp)
        panel = col
    }

    private fun openHtml(html: String) {
        hidePanel()
        startActivity(
            Intent(this, RunActivity::class.java)
                .putExtra("html", html)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /** Запускает JavaScript в закрытом WebView без доступа к сети и показывает вывод. */
    @SuppressLint("SetJavaScriptEnabled")
    private fun runJs(code: String, out: TextView) {
        out.visibility = View.VISIBLE
        out.text = "Выполняется…"
        runner?.destroy()
        val wv = WebView(applicationContext)
        runner = wv
        wv.settings.javaScriptEnabled = true
        wv.settings.blockNetworkLoads = true

        var finished = false
        val finish = { text: String ->
            if (!finished) {
                finished = true
                out.text = text.take(1500).ifBlank { "(код выполнен, но ничего не вывел)" }
                wv.destroy()
                if (runner === wv) runner = null
            }
        }
        wv.addJavascriptInterface(JsBridge(finish), "Android")
        main.postDelayed({ finish("Остановлено: код работает дольше 5 секунд.") }, 5000)

        val b64 = Base64.encodeToString(code.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val html = "<html><body><script>" + RUNNER_JS.replace("__CODE__", b64) + "</script></body></html>"
        wv.loadDataWithBaseURL("https://run.local/", html, "text/html", "utf-8", null)
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    companion object {
        const val ACTION_STOP = "com.example.codebubble.STOP"
        private const val CHANNEL = "bubble"
        private const val BUBBLE_TEXT = "</>"

        private const val RUNNER_JS = """
(function () {
  var logs = [];
  function fmt(a) {
    try {
      if (typeof a === 'string') return a;
      if (a instanceof Error) return String(a);
      var j = JSON.stringify(a);
      return j === undefined ? String(a) : j;
    } catch (e) { return String(a); }
  }
  ['log', 'info', 'warn', 'error'].forEach(function (k) {
    console[k] = function () {
      logs.push((k === 'error' ? '! ' : '') + Array.prototype.map.call(arguments, fmt).join(' '));
    };
  });
  window.onerror = function (m) { logs.push('Ошибка: ' + m); };
  var code = new TextDecoder().decode(Uint8Array.from(atob('__CODE__'), function (c) { return c.charCodeAt(0); }));
  var res;
  try { res = (0, eval)(code); } catch (e) { logs.push('Ошибка: ' + e); }
  if (res !== undefined) logs.push('→ ' + fmt(res));
  setTimeout(function () { Android.report(logs.join('\n')); }, 700);
})();
"""
    }
}
