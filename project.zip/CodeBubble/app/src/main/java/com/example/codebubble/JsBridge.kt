package com.example.codebubble

import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface

/** Принимает вывод кода из WebView. Класс публичный, иначе WebView не сможет вызвать метод. */
class JsBridge(private val onDone: (String) -> Unit) {
    @JavascriptInterface
    fun report(s: String) {
        Handler(Looper.getMainLooper()).post { onDone(s) }
    }
}
