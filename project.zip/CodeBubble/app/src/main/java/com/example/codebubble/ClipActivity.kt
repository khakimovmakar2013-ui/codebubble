package com.example.codebubble

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context

/**
 * Начиная с Android 10 буфер обмена может читать только приложение, у которого есть фокус.
 * Эта прозрачная activity получает фокус, читает буфер и сразу закрывается.
 */
class ClipActivity : Activity() {
    private var done = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || done) return
        done = true

        var text: String? = null
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0) {
                text = clip.getItemAt(0).coerceToText(this)?.toString()?.take(20000)
            }
        } catch (_: Exception) {
        }
        Bridge.onText?.invoke(text)
        finish()
        overridePendingTransition(0, 0)
    }
}
