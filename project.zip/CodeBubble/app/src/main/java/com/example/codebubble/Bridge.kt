package com.example.codebubble

/** Передаёт текст из ClipActivity в BubbleService (оба живут в одном процессе). */
object Bridge {
    @Volatile
    var onText: ((String?) -> Unit)? = null
}
