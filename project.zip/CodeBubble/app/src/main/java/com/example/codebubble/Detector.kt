package com.example.codebubble

import org.json.JSONArray
import org.json.JSONObject

class Verdict(
    val name: String,
    val ext: String,
    val desc: String,
    val label: String,
    val low: Boolean,
    val others: List<String>,
    val secret: Boolean
)

private class Rule(pattern: String, val w: Double, flags: String) {
    val re = Regex(pattern, buildSet {
        if ('m' in flags) add(RegexOption.MULTILINE)
        if ('i' in flags) add(RegexOption.IGNORE_CASE)
    })
}

private fun r(p: String, w: Number, f: String = "") = Rule(p, w.toDouble(), f)

private class Lang(val name: String, val ext: String, val desc: String, val rules: List<Rule>)

private class Kind(
    val name: String,
    val desc: String,
    val secret: Boolean = false,
    val test: (String) -> Boolean
)

private fun full(p: String, flags: Set<RegexOption> = emptySet()): (String) -> Boolean {
    val re = Regex(p, flags)
    return { re.matches(it) }
}

private fun count(re: Regex, t: String) = re.findAll(t).count()

object Detector {

    private val LANGS: List<Lang> = listOf(
        Lang("Python", ".py", "Язык для скриптов, анализа данных и автоматизации.", listOf(
            r("""^\s*def\s+\w+\s*\(.*\)\s*(->\s*[\w\[\], .]+)?\s*:""", 5, "m"),
            r("""^\s*(import\s+[\w.]+|from\s+[\w.]+\s+import\s+)""", 3, "m"),
            r("""\bprint\s*\(""", 2), r("""\bself\b""", 2), r("""\belif\b""", 4),
            r("""\b(None|True|False)\b""", 2),
            r("""^\s*class\s+\w+.*:\s*$""", 4, "m"), r("""__\w+__""", 2), r("""\bf["']""", 1),
            r("""^\s*for\s+\w+\s+in\s+.*:\s*$""", 3, "m"),
            r("""^\s*(if|while|else|try|except|with)\b.*:\s*$""", 2, "m"),
            r("""\brange\(|\blen\(""", 1)
        )),
        Lang("JavaScript", ".js", "Язык веб-страниц и серверов на Node.js.", listOf(
            r("""\b(const|let)\s+[\w{\[]""", 3), r("""=>""", 2), r("""console\.\w+\(""", 4),
            r("""\bfunction\s*\w*\s*\(""", 3), r("""\b(document|window)\.\w+""", 3),
            r("""\brequire\(|module\.exports""", 4),
            r("""^\s*import\s+.+\s+from\s+['"]""", 3, "m"), r("""===|!==""", 2),
            r("""\b(await|async)\b""", 1), r("""\.(then|map|filter|forEach|reduce)\(""", 2),
            r("""\bvar\s+\w+""", 1), r("""`[^`]*\$\{""", 2)
        )),
        Lang("TypeScript", ".ts", "JavaScript с типами. Компилируется в обычный JS.", listOf(
            r(""":\s*(string|number|boolean|any|void|unknown|never)\b""", 5),
            r("""\binterface\s+\w+""", 4), r("""\btype\s+\w+\s*=""", 4),
            r("""\bas\s+(string|number|const|any|unknown)\b""", 3), r("""<\w+(\[\])?>\s*\(""", 1),
            r("""\b(const|let)\s+\w+""", 1.5), r("""=>""", 1), r("""console\.\w+\(""", 1),
            r("""\benum\s+\w+""", 3), r("""\b(readonly|implements)\b""", 2)
        )),
        Lang("HTML", ".html", "Разметка веб-страницы.", listOf(
            r("""<!doctype html""", 8, "i"),
            r("""<(html|head|body|div|span|p|a|ul|ol|li|h[1-6]|script|style|img|button|input|form|table|section|nav|main|header|footer|label|textarea|select)\b[^>]*>""", 4, "i"),
            r("""</\w+>""", 1), r("""\s(class|id|href|src)=["']""", 2)
        )),
        Lang("CSS", ".css", "Стили для веб-страниц.", listOf(
            r("""[.#]?[\w-]+(\s*[>+~,:][^{]*)?\s*\{[^}]*:[^}]*\}""", 4),
            r("""\b(color|margin|padding|display|background|font-size|border|width|height|flex|grid)\s*:""", 3),
            r("""@media|@import|@keyframes|:root""", 3), r("""\b\d+(px|rem|em|vh|vw)\b""", 1),
            r("""var\(--[\w-]+\)""", 2)
        )),
        Lang("SQL", ".sql", "Язык запросов к базам данных.", listOf(
            r("""\bSELECT\b[\s\S]*\bFROM\b""", 7, "i"),
            r("""\b(INSERT\s+INTO|UPDATE\s+\w+\s+SET|DELETE\s+FROM|CREATE\s+TABLE|ALTER\s+TABLE|DROP\s+TABLE)\b""", 7, "i"),
            r("""\b(WHERE|JOIN|GROUP\s+BY|ORDER\s+BY|LIMIT|HAVING)\b""", 2, "i"),
            r("""\b(VALUES|PRIMARY\s+KEY|NOT\s+NULL)\b""", 2, "i")
        )),
        Lang("Bash / терминал", ".sh", "Команды для командной строки Linux и macOS.", listOf(
            r("""^#!.*\b(ba|z)?sh\b""", 9, "m"),
            r("""^\s*(sudo|apt(-get)?|chmod|chown|grep|curl|wget|cd|ls|mkdir|rm|mv|cp|export|cat|echo|npm|npx|pip3?|git|brew|docker|ssh|tar|kill|sed|awk|python3?|node)\b""", 4, "m"),
            r("""\$\{?\w+\}?""", 1), r("""\b(fi|done|esac)\b""", 2),
            r("""^\s*\$\s+\S""", 3, "m"), r("""\s(\||&&|>>)\s""", 1),
            r("""\s--?[a-z][\w-]*""", 1, "i")
        )),
        Lang("C", ".c", "Низкоуровневый язык для систем и микроконтроллеров.", listOf(
            r("""#include\s*<\w+\.h>""", 6), r("""\bint\s+main\s*\(""", 4), r("""\bprintf\s*\(""", 4),
            r("""\b(malloc|free|sizeof)\s*\(""", 3),
            r("""\b(char|int|float|double)\s+\*?\w+\s*(\[.*\])?\s*[=;(]""", 1), r("""->\w+""", 1)
        )),
        Lang("C++", ".cpp", "Язык для игр, драйверов и быстрых программ.", listOf(
            r("""#include\s*<(iostream|vector|string|map|set|algorithm|memory|cstdio)>""", 8),
            r("""\bstd::\w+""", 6), r("""\bcout\s*<<""", 6), r("""\bcin\s*>>""", 5),
            r("""\bnamespace\s+\w+|\busing\s+namespace\b""", 4), r("""\btemplate\s*<""", 4),
            r("""\bint\s+main\s*\(""", 2), r("""\bclass\s+\w+\s*(:|\{)""", 2)
        )),
        Lang("C# (Unity)", ".cs", "Скрипт для игрового движка Unity на языке C#.", listOf(
            r("""\busing\s+UnityEngine""", 9), r("""\bMonoBehaviour\b""", 8),
            r("""\bvoid\s+(Awake|Start|Update|FixedUpdate|LateUpdate|OnEnable|OnDisable|OnCollision\w*|OnTrigger\w*)\s*\(""", 5),
            r("""\b(Transform|Vector2|Vector3|Quaternion|GameObject|Rigidbody2?D?|Camera|Collider)\b""", 3),
            r("""\[(Header|SerializeField|Range|RequireComponent|Tooltip)\b""", 3),
            r("""\bInput\.(GetKey\w*|GetMouse\w*|GetAxis\w*|GetButton\w*)""", 3),
            r("""\bTime\.(deltaTime|time|fixedDeltaTime)\b""", 3),
            r("""\bDebug\.Log\w*\(""", 4), r("""\bPhysics\.Raycast\b""", 3),
            r("""\b(public|private|protected)\s+(class|void|int|float|bool|string)\b""", 2),
            r("""\bforeach\s*\(\s*var\b""", 1)
        )),
        Lang("C#", ".cs", "Язык платформы .NET и игр на Unity.", listOf(
            r("""\busing\s+System""", 7), r("""\bConsole\.(WriteLine|ReadLine|Write)\b""", 7),
            r("""\bnamespace\s+[\w.]+""", 2),
            r("""\b(public|private|protected|internal)\s+(static\s+)?(void|int|string|bool|async)\b""", 2),
            r("""\bvar\s+\w+\s*=""", 1), r("""\{\s*get;\s*(set;)?\s*\}""", 5), r("""\bstring\[\]""", 2)
        )),
        Lang("Java", ".java", "Язык для серверов и Android-приложений.", listOf(
            r("""\bpublic\s+static\s+void\s+main""", 8), r("""System\.out\.print""", 7),
            r("""\bpublic\s+class\s+\w+""", 3), r("""\bimport\s+java\.""", 7), r("""@Override""", 3),
            r("""\b(public|private|protected)\s+(static\s+)?(void|int|String|boolean)\s+\w+\s*\(""", 2),
            r("""\bnew\s+\w+(<.*>)?\(""", 1)
        )),
        Lang("Go", ".go", "Язык Google для серверов и сетевых утилит.", listOf(
            r("""^package\s+\w+""", 5, "m"), r("""\bfunc\s+(\(\w+\s+\*?\w+\)\s*)?\w*\s*\(""", 5),
            r("""\bfmt\.\w+\(""", 6), r("""\w+\s*:=\s*""", 3), r("""\b(defer|chan|go\s+func)\b""", 3),
            r("""\bimport\s+\(""", 4)
        )),
        Lang("Rust", ".rs", "Язык с упором на безопасность памяти и скорость.", listOf(
            r("""\bfn\s+\w+\s*(<.*>)?\(""", 5), r("""\blet\s+mut\b""", 6),
            r("""\b(println|print|format|vec|panic)!\s*\(""", 6), r("""\bimpl\b|\buse\s+std::""", 4),
            r("""&str\b|\bVec<|\bOption<|\bResult<""", 3), r("""\bmatch\s+\w+.*\{""", 2),
            r("""->\s*[\w<>&]+\s*\{""", 1)
        )),
        Lang("PHP", ".php", "Язык для серверной части сайтов.", listOf(
            r("""<\?php""", 9), r("""\x24\w+\s*=""", 2), r("""\becho\b""", 1), r("""\x24\w+->\w+""", 3),
            r("""\bfunction\s+\w+\s*\(\s*\x24""", 4), r("""\x24_(GET|POST|SESSION|SERVER)\b""", 6),
            r("""\barray\s*\(""", 2)
        )),
        Lang("Ruby", ".rb", "Язык для сайтов на Rails и скриптов.", listOf(
            r("""\bdef\s+\w+[?!]?(\(.*\))?\s*$""", 3, "m"), r("""\bputs\b""", 4),
            r("""\bdo\s*\|\w+(,\s*\w+)*\|""", 5), r("""\battr_(accessor|reader|writer)\b""", 5),
            r("""^\s*end\s*$""", 3, "m"), r("""@\w+\s*=""", 1), r("""\brequire\s+['"]""", 2),
            r("""\.each\s+do\b""", 3)
        )),
        Lang("Kotlin", ".kt", "Язык для Android и серверов на JVM.", listOf(
            r("""\bfun\s+\w+\s*\(""", 6), r("""\b(val|var)\s+\w+\s*(:|=)""", 3), r("""\bprintln\s*\(""", 1),
            r("""\bwhen\s*(\(.*\))?\s*\{""", 4), r("""\bdata\s+class\b""", 6), r("""\?\.""", 1)
        )),
        Lang("Swift", ".swift", "Язык Apple для iPhone и Mac.", listOf(
            r("""\bimport\s+(UIKit|SwiftUI|Foundation)\b""", 8),
            r("""\bfunc\s+\w+\s*\(.*\)\s*(->\s*[\w\[\]?]+)?\s*\{""", 4), r("""\bguard\s+let\b""", 6),
            r("""\bvar\s+\w+\s*:\s*\w+""", 2), r("""\blet\s+\w+\s*[:=]""", 1), r("""\bprint\s*\(""", 1),
            r("""\bstruct\s+\w+\s*:\s*\w+""", 3)
        )),
        Lang("Lua", ".lua", "Лёгкий язык для игр и скриптов внутри программ.", listOf(
            r("""\blocal\s+\w+""", 4), r("""\bfunction\s+[\w.:]+\s*\(.*\)""", 1), r("""\bthen\b""", 1),
            r("""^\s*end\s*$""", 1, "m"), r("""\bnil\b""", 2), r("""\bprint\s*\(""", 1),
            r("""\bipairs|\bpairs\b""", 4)
        )),
        Lang("YAML", ".yml", "Формат настроек: ключи и значения с отступами.", listOf(
            r("""^[\w.-]+:\s*(\S.*)?$""", 2, "m"), r("""^\s*-\s+[\w.-]+:\s""", 3, "m"),
            r("""^---\s*$""", 3, "m"), r("""^\s*-\s+\S""", 1, "m")
        )),
        Lang("XML", ".xml", "Формат разметки данных с тегами.", listOf(
            r("""<\?xml\b""", 9), r("""<\w+(\s[^>]*)?>[\s\S]*</\w+>""", 2), r("""<\w+\s+xmlns""", 4)
        )),
        Lang("Markdown", ".md", "Простая разметка текста: заголовки, списки, ссылки.", listOf(
            r("""^#{1,6}\s+\S""", 3, "m"), r("""\*\*[^*\n]+\*\*""", 2), r("""^\s*[-*]\s+\S""", 1, "m"),
            r("""\[[^\]]+\]\([^)]+\)""", 3), r("""```""", 5)
        )),
        Lang("Dockerfile", "Dockerfile", "Инструкция для сборки образа контейнера Docker.", listOf(
            r("""^FROM\s+\S+""", 8, "m"),
            r("""^(RUN|CMD|COPY|ADD|EXPOSE|WORKDIR|ENTRYPOINT|ENV|ARG)\s""", 4, "m")
        )),
        Lang("Diff / патч", ".diff", "Список изменений в файлах, как в Git.", listOf(
            r("""^@@ .* @@""", 8, "m"), r("""^(\+\+\+|---)\s\S""", 4, "m"), r("""^diff --git""", 8, "m")
        )),
        Lang("Регулярное выражение", "", "Шаблон для поиска и замены в тексте.", listOf(
            r("""^/.+/[gimsuy]*$""", 7), r("""\\[dws]\+?|\[\^?[\w-]+\][+*?]|\(\?:|\(\?<?[=!]""", 3)
        ))
    )

    private val KINDS: List<Kind> = listOf(
        Kind("Ссылка (URL)", "Адрес в интернете.", false, full("""https?://\S+""", setOf(RegexOption.IGNORE_CASE))),
        Kind("Адрес почты", "Электронная почта.", false, full("""[^\s@]+@[^\s@]+\.[^\s@]{2,}""")),
        Kind("HEX-цвет", "Цвет для сайтов и дизайна.", false,
            full("""#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})""", setOf(RegexOption.IGNORE_CASE))),
        Kind("UUID", "Уникальный идентификатор, например записи в базе.", false,
            full("""[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}""", setOf(RegexOption.IGNORE_CASE))),
        Kind("IP-адрес", "Адрес устройства в сети.", false, full("""(\d{1,3}\.){3}\d{1,3}(:\d+)?""")),
        Kind("JWT-токен", "Токен входа. Внутри данные о пользователе.", true, full("""eyJ[\w-]+\.[\w-]+\.[\w-]*""")),
        Kind("Токен Telegram-бота", "Ключ для управления ботом.", true, full("""\d{8,10}:[\w-]{35}""")),
        Kind("Секретный ключ API", "Ключ доступа к сервису.", true,
            full("""(sk|pk|ghp|gho|ghs|xox[bpa]|AKIA)[-_A-Za-z0-9]{16,}""")),
        Kind("Base64", "Данные, записанные буквами и цифрами. Обычно это закодированный текст или файл.", false, run {
            val re = Regex("""[A-Za-z0-9+/]+={0,2}""")
            val t: (String) -> Boolean = { s ->
                s.length >= 16 && s.length % 4 == 0 && re.matches(s) &&
                    s.any { it.isUpperCase() } && s.any { it.isLowerCase() }
            }
            t
        }),
        Kind("HEX-строка", "Байты в шестнадцатеричном виде: хеш, ключ или бинарные данные.", false,
            full("""(0x)?[0-9a-f]{16,}""", setOf(RegexOption.IGNORE_CASE))),
        Kind("Ключ или промокод", "Набор букв и цифр через дефис, как у лицензий и купонов.", false,
            full("""[A-Z0-9]{3,}(-[A-Z0-9]{3,})+"""))
    )

    private fun validJson(t: String): Boolean = try {
        when {
            t.startsWith("{") -> { JSONObject(t); true }
            t.startsWith("[") -> { JSONArray(t); true }
            else -> false
        }
    } catch (_: Exception) {
        false
    }

    private class Scored(val name: String, val ext: String, val desc: String, val score: Double)

    fun detect(raw: String): Verdict {
        val text = raw.trim()

        if (text.none { it.isWhitespace() }) {
            for (k in KINDS) {
                if (k.test(text)) return Verdict(k.name, "", k.desc, "Уверенно", false, emptyList(), k.secret)
            }
        }

        val list = ArrayList<Scored>()
        val json = validJson(text)
        if (json) {
            list.add(Scored("JSON", ".json", "Формат данных: ключи и значения в скобках. Здесь он корректный.", 12.0))
        }

        val quoteRe = Regex("""\x22[^\x22]*\x22""")
        val keyLineRe = Regex("""^[\w.-]+:\s*(\S.*)?$""", RegexOption.MULTILINE)
        val punct = Regex("""[{};]""")

        for (l in LANGS) {
            var s = 0.0
            for (rule in l.rules) if (rule.re.containsMatchIn(text)) s += rule.w
            if (l.name == "YAML") {
                if (punct.containsMatchIn(text.replace(quoteRe, ""))) s = maxOf(0.0, s - 3)
                if (count(keyLineRe, text) < 2) s = maxOf(0.0, s - 2)
            }
            if (s > 0) list.add(Scored(l.name, l.ext, l.desc, s))
        }
        if (!json && Regex("""^[\[{]""").containsMatchIn(text) && Regex("""\x22[^\x22]+\x22\s*:""").containsMatchIn(text)) {
            list.add(Scored("JSON", ".json", "Похоже на JSON, но в нём ошибка: лишняя запятая, кавычки или скобка.", 5.0))
        }
        list.sortByDescending { it.score }

        if (list.isEmpty() || list[0].score < 2) {
            return Verdict(
                "Обычный текст", "",
                "Знакомых признаков кода не нашлось. Попробуй скопировать кусок побольше.",
                "Не уверен", true, emptyList(), false
            )
        }

        val best = list[0]
        val second = if (list.size > 1) list[1].score else 0.0
        val margin = (best.score - second) / best.score
        val (label, low) = when {
            best.score >= 8 && margin >= 0.35 -> "Уверенно" to false
            best.score >= 4 && margin >= 0.2 -> "Скорее всего" to false
            else -> "Возможно" to true
        }
        val others = list.drop(1).filter { it.score >= 2 }.take(2).map { it.name }
        return Verdict(best.name, best.ext, best.desc, label, low, others, false)
    }
}
