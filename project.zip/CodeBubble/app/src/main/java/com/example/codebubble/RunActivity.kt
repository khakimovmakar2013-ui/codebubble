package com.example.codebubble

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView

/** Показывает HTML-страницу из буфера на весь экран. Закрывается кнопкой «назад». */
class RunActivity : Activity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        setContentView(wv)
        wv.loadDataWithBaseURL(
            "https://run.local/",
            intent.getStringExtra("html") ?: "",
            "text/html", "utf-8", null
        )
    }
}
